THE VEIL - Windows build (Phase 1 opening + Phase 2 town errands)

Unzip, then double-click TheVeil.exe.
Windows SmartScreen may warn because the exe is unsigned: click "More info" > "Run anyway".
Needs a GPU with OpenGL 3.3.

Controls: WASD move, mouse look, Shift sprint, Ctrl crouch, E interact, Tab inventory, Esc pause.
In the car: W gas, S brake/reverse, A/D steer, Space handbrake, E exit.
