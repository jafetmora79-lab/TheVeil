THE VEIL - Windows build (opening, town errands with stocked stores, the Veil and the Colossus encounter)

Unzip, then double-click TheVeil.exe.
Windows SmartScreen may warn because the exe is unsigned: click "More info" > "Run anyway".
Needs a GPU with OpenGL 3.3.

Controls: WASD move, mouse look, Shift sprint, Ctrl crouch, E interact, Tab inventory, Esc pause.
In the car: W gas, S brake/reverse, A/D steer, Space handbrake, E exit.

New: Shift sprint uses stamina once the mist arrives. Keep away from the tentacles in the street.
