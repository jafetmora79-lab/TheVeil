@echo off
rem THE VEIL - unlock the chapter list (Main Menu > Chapters) on this PC.
if not exist "%APPDATA%\Godot\app_userdata\THE VEIL" mkdir "%APPDATA%\Godot\app_userdata\THE VEIL"
echo {"all_chapters": true}> "%APPDATA%\Godot\app_userdata\THE VEIL\veil_chapters.json"
echo All chapters unlocked. Start THE VEIL and open Chapters on the main menu.
pause
