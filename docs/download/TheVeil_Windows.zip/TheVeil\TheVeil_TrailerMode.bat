@echo off
REM THE VEIL - trailer / capture mode: F1 help, F9 clean screen, F8 free camera, F5/F6/F7 shots, F4 slow motion, F11 jump.
cd /d "%~dp0"
start "" "TheVeil.exe" -- --trailer
